package com.calculator.vault

import android.app.Activity
import android.content.Context
import android.net.Uri
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebView
import android.widget.Toast
import com.calculator.vault.managers.CalendarManager
import com.calculator.vault.managers.ContactManager
import com.calculator.vault.managers.FileManager
import com.calculator.vault.managers.NotificationManager
import com.calculator.vault.security.EncryptionHelper
import org.json.JSONArray
import org.json.JSONObject

/**
 * Bridges the JS calculator UI (assets/vault/index.html, window.vaultNative /
 * window.nativeStorage) to the native managers. Every method the JS side calls
 * on `AndroidBridge` must exist here with the exact name/arity it expects.
 */
class WebAppInterface(
    private val activity: Activity,
    private val webView: WebView,
    private val encryptionHelper: EncryptionHelper
) {

    companion object {
        const val FILE_CHOOSER_REQUEST = 1000
        const val CAPTURE_IMAGE_REQUEST = 1001
        const val CAPTURE_VIDEO_REQUEST = 1002
    }

    var filePathCallback: ValueCallback<Array<Uri>>? = null

    private val fileManager by lazy { FileManager(activity) }
    private val contactManager by lazy { ContactManager(activity) }
    private val calendarManager by lazy { CalendarManager(activity) }
    private val notificationManager by lazy { NotificationManager(activity) }

    // ---- JSON response helpers -------------------------------------------------
    // The JS side always does JSON.parse(...) on string returns and expects
    // {"success": true, "data": ...} or {"success": false, "error": "..."}.

    private fun success(data: Any?): String =
        JSONObject().put("success", true).put("data", toJsonValue(data)).toString()

    private fun failure(message: String?): String =
        JSONObject().put("success", false).put("error", (message ?: "Unknown error")).toString()

    private fun toJsonValue(value: Any?): Any? = when (value) {
        null -> JSONObject.NULL
        is Map<*, *> -> JSONObject().apply {
            value.forEach { (k, v) -> put(k.toString(), toJsonValue(v)) }
        }
        is List<*> -> JSONArray().apply {
            value.forEach { put(toJsonValue(it)) }
        }
        else -> value
    }

    // ---- Vault data (backs window.nativeStorage / localStorage shim) ----------

    @JavascriptInterface
    fun setPin(pin: String): String = try {
        encryptionHelper.setPin(pin)
        success(mapOf("set" to true))
    } catch (e: Exception) {
        failure(e.message)
    }

    @JavascriptInterface
    fun verifyPin(pin: String): String = try {
        success(mapOf("valid" to encryptionHelper.verifyPin(pin)))
    } catch (e: Exception) {
        failure(e.message)
    }

    @JavascriptInterface
    fun storeVaultData(key: String, value: String, pin: String) {
        try {
            encryptionHelper.storeVaultData(key, value, pin)
        } catch (e: Exception) {
            // Fire-and-forget from the JS side (setItem has no return value),
            // so just avoid crashing the bridge thread on failure.
        }
    }

    @JavascriptInterface
    fun retrieveVaultData(key: String, pin: String): String = try {
        val data = encryptionHelper.retrieveVaultData(key, pin)
        if (data != null) success(mapOf("data" to data)) else failure("Not found or wrong PIN")
    } catch (e: Exception) {
        failure(e.message)
    }

    @JavascriptInterface
    fun deleteVaultData(key: String) {
        try {
            activity.getSharedPreferences("vault_data", Context.MODE_PRIVATE)
                .edit().remove(key).apply()
        } catch (e: Exception) {
        }
    }

    // ---- Files ------------------------------------------------------------------

    @JavascriptInterface
    fun getStorageInfo(): String = try {
        success(fileManager.getStorageInfo())
    } catch (e: Exception) {
        failure(e.message)
    }

    @JavascriptInterface
    fun listFiles(path: String): String = try {
        success(fileManager.listFiles(path))
    } catch (e: Exception) {
        failure(e.message)
    }

    // ---- Contacts / Calendar -----------------------------------------------------

    @JavascriptInterface
    fun importContacts(): String = try {
        success(contactManager.importContacts())
    } catch (e: Exception) {
        failure(e.message)
    }

    @JavascriptInterface
    fun getCalendarEvents(start: Long, end: Long): String = try {
        success(calendarManager.getEvents(start, end))
    } catch (e: Exception) {
        failure(e.message)
    }

    // ---- Notifications / misc -----------------------------------------------------

    @JavascriptInterface
    fun scheduleNotification(title: String, message: String, triggerTime: Long) {
        try {
            notificationManager.scheduleNotification(title, message, triggerTime)
        } catch (e: Exception) {
        }
    }

    @JavascriptInterface
    fun showToast(message: String) {
        activity.runOnUiThread {
            Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()
        }
    }
}
